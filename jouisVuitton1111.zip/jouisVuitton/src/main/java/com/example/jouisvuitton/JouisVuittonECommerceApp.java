package com.example.jouisvuitton;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.control.ScrollPane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Popup;
import javafx.stage.Screen;
import javafx.stage.Stage;

import java.io.File;
import java.util.List;
import java.util.stream.Collectors;
import java.util.ArrayList;



public class JouisVuittonECommerceApp extends Application {

    private Scene mainScene;
    private Cart cart = new Cart();

    @Override
    public void start(Stage stage) {
        Database.initialize();

        // Screen dimensions
        double screenWidth = Screen.getPrimary().getBounds().getWidth();
        double screenHeight = Screen.getPrimary().getBounds().getHeight();

        // Background Image
        Image backgroundImage = new Image("file:C:/Users/Mirei/Desktop/jouisVuitton/src/theme/pink.jpg");
        ImageView backgroundImageView = new ImageView(backgroundImage);
        backgroundImageView.setPreserveRatio(false);
        backgroundImageView.setFitWidth(screenWidth);
        backgroundImageView.setFitHeight(screenHeight);

        // Sale Banner
        Image saleImage = new Image("file:C:/Users/Mirei/Desktop/jouisVuitton/src/WEB_SALE_UPDATE_19_AUG-29_x840.jpg");
        ImageView saleBanner = new ImageView(saleImage);
        saleBanner.setFitWidth(screenWidth);
        saleBanner.setFitHeight(150);
        saleBanner.setPreserveRatio(false);

        ColorAdjust darkenEffect = new ColorAdjust();
        darkenEffect.setBrightness(-0.5);
        saleBanner.setOnMouseEntered(event -> saleBanner.setEffect(darkenEffect));
        saleBanner.setOnMouseExited(event -> saleBanner.setEffect(null));
        saleBanner.setOnMouseClicked(event -> {
            ClothesSaleApp clothesApp = new ClothesSaleApp(stage, Cart.getInstance());
            clothesApp.start(new Stage());
            stage.hide();

        });

        // Create Login and Sign-Up Buttons
        Button loginButton = new Button("Login");
        Button signUpButton = new Button("Create an account");

        // Style frameless buttons
        String framelessStyle = "-fx-background-color: transparent; -fx-text-fill: #ff69b4; -fx-font-size: 16px; -fx-font-weight: bold; -fx-cursor: hand;";
        loginButton.setStyle(framelessStyle);
        signUpButton.setStyle(framelessStyle);

        // Add event handling
        loginButton.setOnAction(e -> {
            LoginPage loginPage = new LoginPage();
            loginPage.start(stage); // Assuming LoginPage has a `start` method that accepts the stage
        });

        signUpButton.setOnAction(e -> {
            SignUpPage signUpPage = new SignUpPage();
            signUpPage.start(stage); // Assuming SignUpPage has a `start` method that accepts the stage
        });

        // Place buttons in an HBox
        HBox loginSignUpBox = new HBox(10, loginButton, signUpButton);
        loginSignUpBox.setAlignment(Pos.TOP_RIGHT);
        loginSignUpBox.setPadding(new Insets(10));

        // Top Layout with Sale Banner and Buttons
        VBox topLayout = new VBox(10);
        topLayout.setAlignment(Pos.TOP_LEFT);
        topLayout.setPadding(new Insets(10));
        topLayout.getChildren().addAll(saleBanner, loginSignUpBox);

        // Add Search Bar
        createSearchBar(topLayout, stage);

        // Filter categories to exclude "In Sale"
        List<Category> categories = Database.categories.stream()
                .filter(category -> !"In Sale".equalsIgnoreCase(category.getName()))
                .collect(Collectors.toList());

        // Create Category Grid
        GridPane categoryGrid = createCategoryGrid(categories, stage);

        // Wrap the grid in a ScrollPane
        ScrollPane categoryScrollPane = new ScrollPane();
        categoryScrollPane.setContent(categoryGrid);
        categoryScrollPane.setFitToWidth(true);
        categoryScrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.ALWAYS);
        topLayout.getChildren().add(categoryScrollPane);

        // View Cart Button
        Image cartImage = new Image("file:C:/Users/Mirei/Desktop/jouisVuitton/src/shopping_cart_PNG38-removebg-preview.png");
        ImageView cartImageView = new ImageView(cartImage);
        cartImageView.setFitWidth(60);
        cartImageView.setFitHeight(60);

        Button viewCartButton = new Button();
        viewCartButton.setGraphic(cartImageView);
        viewCartButton.setStyle("-fx-background-color: transparent; -fx-cursor: hand;");
        viewCartButton.setOnAction(e -> showCart(stage));
        topLayout.getChildren().add(viewCartButton);

        // Root Layout with GridPane
        GridPane root = new GridPane();
        root.setAlignment(Pos.TOP_LEFT);
        root.setPadding(new Insets(0));
        root.add(backgroundImageView, 0, 0, GridPane.REMAINING, GridPane.REMAINING);
        root.add(topLayout, 0, 0);

        // Set the scene
        mainScene = new Scene(root, screenWidth, screenHeight);

        stage.setFullScreen(true);
        stage.setTitle("Jouis Vuitton - E-Commerce App");
        stage.setScene(mainScene);
        stage.setOnCloseRequest(event -> System.out.println("Application closed."));
        stage.show();
    }


    private void createSearchBar(VBox topLayout, Stage stage) {
        TextField searchBar = new TextField();
        searchBar.setPromptText("Search for a product...");
        searchBar.setStyle(
                "-fx-font-size: 14px; " +
                        "-fx-background-color: #ffe4e1; " +
                        "-fx-border-radius: 10;" +
                        "-fx-padding: 5;"
        );
        searchBar.setPrefWidth(330);
        searchBar.setMaxWidth(330);
        searchBar.setMinWidth(330);

        ListView<String> listView = new ListView<>();
        listView.setMaxHeight(250);
        listView.setPrefWidth(330);



        Popup popup = new Popup();
        popup.getContent().add(listView);
        popup.setAutoHide(true);

        searchBar.textProperty().addListener((observable, oldValue, newValue) -> {
            String searchTerm = newValue.toLowerCase().trim();
            if (searchTerm.isEmpty()) {
                popup.hide();
                return;
            }

            List<String> matchedProducts = Database.products.stream()
                    .filter(product -> product.getName().toLowerCase().contains(searchTerm))
                    .map(product -> product.getName() + " - EGP" + product.getPrice())
                    .collect(Collectors.toList());

            if (!matchedProducts.isEmpty()) {
                listView.getItems().setAll(matchedProducts);
                if (!popup.isShowing()) {
                    popup.show(stage);
                    popup.setX(searchBar.localToScreen(searchBar.getBoundsInLocal()).getMinX());
                    popup.setY(searchBar.localToScreen(searchBar.getBoundsInLocal()).getMaxY());
                }
            } else {
                popup.hide();
            }
        });

        listView.setOnMouseClicked(event -> {
            String selectedItem = listView.getSelectionModel().getSelectedItem();
            if (selectedItem != null) {
                String productName = selectedItem.split(" - ")[0].trim();
                Product selectedProduct = Database.products.stream()
                        .filter(product -> product.getName().equalsIgnoreCase(productName))
                        .findFirst()
                        .orElse(null);
                if (selectedProduct != null) {
                    showProductDetailsScreen(stage, selectedProduct);
                }
                popup.hide();
            }
        });

        searchBar.setOnAction(event -> {
            String selectedItem = listView.getSelectionModel().getSelectedItem();
            if (selectedItem != null) {
                String productName = selectedItem.split(" - ")[0].trim();
                Product selectedProduct = Database.products.stream()
                        .filter(product -> product.getName().equalsIgnoreCase(productName))
                        .findFirst()
                        .orElse(null);
                if (selectedProduct != null) {
                    showProductDetailsScreen(stage, selectedProduct);
                }
                popup.hide();
            }
        });

        topLayout.getChildren().add(searchBar);
    }

    private Button createBackToMainButton(Stage stage) {
        Button backButton = new Button("Back to Main");
        backButton.setStyle("-fx-background-color: #ffe4e1; -fx-text-fill: white; -fx-font-weight: bold;");
        backButton.setOnAction(e -> stage.setScene(mainScene));
        return backButton;
    }

    private GridPane createCategoryGrid(List<Category> categories, Stage stage) {
        GridPane gridPane = new GridPane();
        gridPane.setHgap(20);
        gridPane.setVgap(20);
        gridPane.setPadding(new Insets(20));
        gridPane.setAlignment(Pos.CENTER_LEFT);

        int column = 0;
        int row = 0;

        for (Category category : categories) {
            Image image = loadImageWithFallback(category.getImagePath(), "src/products/default.jpg");

            ImageView imageView = new ImageView(image);
            imageView.setFitWidth(300);
            imageView.setFitHeight(300);
            imageView.setPreserveRatio(true);

            Button categoryButton = new Button();
            VBox buttonContent = new VBox(5, imageView, new Label(category.getName()));
            buttonContent.setAlignment(Pos.CENTER);
            categoryButton.setGraphic(buttonContent);
            categoryButton.setStyle("-fx-background-color: transparent; -fx-cursor: hand;");

            categoryButton.setOnMouseEntered(e -> categoryButton.setStyle(
                    "-fx-background-color: rgba(0, 0, 0, 0.3); -fx-cursor: hand;"));
            categoryButton.setOnMouseExited(e -> categoryButton.setStyle(
                    "-fx-background-color: transparent; -fx-cursor: hand;"));

            // Update to call openCategoryStages
            categoryButton.setOnAction(event -> openCategoryStages(category));

            gridPane.add(categoryButton, column, row);

            column++;
            if (column == 5) {
                column = 0;
                row++;
            }
        }

        return gridPane;
    }

    private void openCategoryStages(Category category) {
        Stage categoryStage = new Stage();
        categoryStage.setTitle(category.getName());

        GridPane mainLayout = new GridPane();
        mainLayout.setHgap(20);
        mainLayout.setVgap(20);
        mainLayout.setAlignment(Pos.CENTER);

        // Back Button
        Button backButton = new Button("← Back");
        backButton.setStyle(
                "-fx-background-color: #FFC0CB; -fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: bold; -fx-cursor: hand;");
        backButton.setOnAction(e -> categoryStage.close()); // Close the category stage and go back to the homepage

        // Header with Back Button and Category Header
        Text categoryHeader = new Text("Shop Our Premium " + category.getName() + " Collection!");
        categoryHeader.setFont(Font.font("Arial", 26));

        HBox headerBox = new HBox(10);
        headerBox.setAlignment(Pos.CENTER);
        headerBox.setStyle("-fx-background-color: #FFC0CB;");
        headerBox.setPadding(new Insets(20));
        headerBox.getChildren().addAll(backButton, categoryHeader);

        mainLayout.add(headerBox, 0, 0, 3, 1);

        ArrayList<Product> products = category.getProducts();

        for (int i = 0; i < products.size(); i++) {
            Product product = products.get(i);

            VBox productBox = new VBox(20);
            productBox.setAlignment(Pos.CENTER);
            productBox.setStyle("-fx-background-color: #FFF1Fa;");

            File file = new File(product.getImagePath());
            Image image;
            if (file.exists()) {
                image = new Image(file.toURI().toString());
            } else {
                image = new Image(new File(Database.defaultImagePath).toURI().toString());
            }

            ImageView imageView = new ImageView(image);
            imageView.setFitWidth(150);
            imageView.setFitHeight(200);
            imageView.setPreserveRatio(true);
            imageView.setSmooth(true);

            Text productName = new Text(product.getName());
            productName.setFont(Font.font("Arial", 18));

            Text productPrice = new Text("Price: " + product.getPrice() + " EGP");
            productPrice.setFont(Font.font("Arial", 16));

            Button addToCartButton = new Button("Add to Cart");
            addToCartButton.setOnAction(e -> Cart.addItem(product));

            productBox.getChildren().addAll(imageView, productName, productPrice, addToCartButton);

            mainLayout.add(productBox, i % 3, (i / 3) + 1);
        }

        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setContent(mainLayout);
        scrollPane.setFitToWidth(true);

        Scene scene = new Scene(scrollPane, 800, 600);

        categoryStage.setScene(scene);
        categoryStage.setFullScreen(true); // Enable full-screen mode
        categoryStage.show();
    }





    private void showProductDetailsScreen(Stage stage, Product product) {
        VBox layout = new VBox(20);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(20));

        Image productImage = loadImageWithFallback(product.getImagePath(), "src/products/default.jpg");
        ImageView productImageView = new ImageView(productImage);
        productImageView.setFitWidth(300);
        productImageView.setFitHeight(300);
        productImageView.setPreserveRatio(true);

        Label productName = new Label(product.getName());
        productName.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        Label productPrice = new Label("Price: EGP " + product.getPrice());
        productPrice.setStyle("-fx-font-size: 16px;");

        Label productDescription = new Label(product.getDescription() != null ? product.getDescription() : "No description available.");
        productDescription.setStyle("-fx-font-size: 14px; -fx-wrap-text: true;");
        productDescription.setWrapText(true);

        Button addToCartButton = new Button("Add to Cart");
        addToCartButton.setStyle("-fx-background-color: #ff69b4; -fx-text-fill: white; -fx-font-weight: bold;");
        addToCartButton.setOnAction(e -> Cart.addItem(product));

        Button backButton = createBackToMainButton(stage);

        layout.getChildren().addAll(productImageView, productName, productPrice, productDescription, addToCartButton, backButton);

        Scene productDetailsScene = new Scene(layout, Screen.getPrimary().getBounds().getWidth(), Screen.getPrimary().getBounds().getHeight());
        stage.setScene(productDetailsScene);
        stage.setFullScreen(true);
    }

    private void showProductsForCategory(Stage stage, Category category) {
        List<Product> products = Database.products.stream()
                .filter(product -> product.getCategory().getName().equalsIgnoreCase(category.getName()))
                .collect(Collectors.toList());

        GridPane productGrid = new GridPane();
        productGrid.setHgap(20);
        productGrid.setVgap(20);
        productGrid.setPadding(new Insets(20));
        productGrid.setAlignment(Pos.CENTER);

        int column = 0;
        int row = 0;

        for (Product product : products) {
            addProductToGrid(productGrid, product.getImagePath(), product.getName(), column, row);
            column++;
            if (column == 2) {
                column = 0;
                row++;
            }
        }

        Button backButton = createBackToMainButton(stage);

        VBox layout = new VBox(20);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(20));
        layout.getChildren().addAll(new Label("Products in " + category.getName()), productGrid, backButton);

        ScrollPane productScrollPane = new ScrollPane();
        productScrollPane.setContent(layout);
        productScrollPane.setFitToWidth(true);
        productScrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.ALWAYS);

        Scene productScene = new Scene(productScrollPane, Screen.getPrimary().getBounds().getWidth(), Screen.getPrimary().getBounds().getHeight());
        stage.setScene(productScene);
        stage.setFullScreen(true);
    }

    private void addProductToGrid(GridPane grid, String imagePath, String name, int column, int row) {
        Image image = loadImageWithFallback(imagePath, "src/products/default.jpg");
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(150);
        imageView.setFitHeight(150);
        imageView.setPreserveRatio(true);

        Label nameLabel = new Label(name);
        nameLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        Button addToCartButton = new Button("Add to Cart");
        addToCartButton.setStyle("-fx-background-color: #ff69b4; -fx-text-fill: white; -fx-font-weight: bold;");
        addToCartButton.setOnAction(e -> {
            Product product = Database.products.stream()
                    .filter(p -> p.getName().equalsIgnoreCase(name))
                    .findFirst()
                    .orElse(null);
            if (product != null) {
                Cart.addItem(product);
            }
        });

        VBox productBox = new VBox(10);
        productBox.setAlignment(Pos.CENTER);
        productBox.getChildren().addAll(imageView, nameLabel, addToCartButton);

        grid.add(productBox, column, row);
    }

    private Image loadImageWithFallback(String imagePath, String fallbackPath) {
        try {
            return new Image("file:" + imagePath);
        } catch (Exception e) {
            System.out.println("Error loading image: " + imagePath + " | Using fallback.");
            return new Image("file:" + fallbackPath);
        }
    }
    private void showCart(Stage stage) {
        VBox cartLayout = new VBox(20);
        cartLayout.setPadding(new Insets(20));
        cartLayout.setAlignment(Pos.CENTER);

        Label cartTitle = new Label("Your Cart");
        cartTitle.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");
        cartLayout.getChildren().add(cartTitle);

        if (Cart.getItems().isEmpty()) {
            cartLayout.getChildren().add(new Label("Your cart is empty."));
        } else {
            VBox itemsLayout



                    = new VBox(10); // Layout to hold cart items
            itemsLayout.setAlignment(Pos.CENTER_LEFT);

            for (Product product : Cart.getItems()) {
                HBox productBox = new HBox(10);
                productBox.setAlignment(Pos.CENTER_LEFT);

                // Product Image
                Image productImage = loadImageWithFallback(product.getImagePath(), "src/products/default.jpg");
                ImageView productImageView = new ImageView(productImage);
                productImageView.setFitWidth(100);
                productImageView.setFitHeight(100);
                productImageView.setPreserveRatio(true);

                // Product Details
                VBox productDetails = new VBox(5);
                productDetails.setAlignment(Pos.CENTER_LEFT);
                Label productName = new Label(product.getName());
                productName.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
                Label productPrice;
                if (product instanceof ProductSale) {
                    productPrice = new Label("Price: EGP " + ((ProductSale) product).getDiscountedPrice());
                    productPrice.setStyle("-fx-font-size: 14px;");
                } else {
                    productPrice = new Label("Price: EGP " + product.getPrice());
                    productPrice.setStyle("-fx-font-size: 14px;");
                }

                productDetails.getChildren().addAll(productName, productPrice);
                productBox.getChildren().addAll(productImageView, productDetails);
                itemsLayout.getChildren().add(productBox);
            }

            cartLayout.getChildren().add(itemsLayout);

            // Total Amount
            double totalAmount = Cart.calculateTotal();
            Label totalLabel = new Label("Total Amount: EGP " + String.format("%.2f", totalAmount));
            totalLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #8B0000;");
            cartLayout.getChildren().add(totalLabel);

            // Checkout Button
            Button checkoutButton = new Button("Checkout");
            checkoutButton.setStyle("-fx-background-color: #ff69b4; -fx-text-fill: white; -fx-font-weight: bold;");
            checkoutButton.setOnAction(e -> Checkout.showCheckoutForm(stage, mainScene)); // Pass stage and mainScene
            cartLayout.getChildren().add(checkoutButton);
        }

        Button backButton = createBackToMainButton(stage);
        cartLayout.getChildren().add(backButton);

        Scene cartScene = new Scene(cartLayout, Screen.getPrimary().getBounds().getWidth(), Screen.getPrimary().getBounds().getHeight());
        stage.setScene(cartScene);
        stage.setFullScreen(true);
    }







    public static void main(String[] args) {
        launch(args);
    }
}
