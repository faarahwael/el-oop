package com.example.jouisvuitton;

import java.util.ArrayList;
import java.util.List;


class Category{
    private  String name;
    private String description;
    private ArrayList<Product> products;
    private String imagePath;


    Category(String categoryName){
    }

    public Category(String name, String description,String imagePath) {
        this.name = name;
        this.description = description;
        this.products = new ArrayList<>();
        this.imagePath=imagePath;
    }


    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public String getImagePath() {
        return imagePath;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public ArrayList<Product> getProducts() {
        return products;
    }

    /**public ArrayList<ProductSale> getProductSales(){
        return productSales;
    }**/

    public void addProduct(Product product) {
        products.add(product);
    }

    public void addSale(ProductSale productSales){
        productSales.add(productSales);
    }

    public void removeProduct(Product product) {
        if (products.contains(product)) {
            products.remove(product);
        } else {
            System.out.println("Product not found in category.");
        }
    }

    public void listProducts() {
        System.out.println("Products in category: " + name);
        for (Product product : products) {
            System.out.println(product);
        }
    }

    public String toString() {
        return "Category: " + name + " - " + description;
    }
}

class Product{
    private String id;
    private String name;
    private String description;
    private double price;
    private int stockQuantity;
    private Category category;
    private String imagePath;

    public Product() {

    }

    public Product(String id, String name, String description, int stockQuantity, Category category, double price, String imagePath) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.price = price;
        this.stockQuantity = stockQuantity;
        this.category = category;
        this.imagePath=imagePath;
    }

    public Product(ProductSale productSale) {
        this.name = productSale.getName();
        this.description = productSale.getDescription();
        this.price = productSale.getDiscountedPrice();
        this.stockQuantity = productSale.getStockQuantity();
        this.imagePath = productSale.getImagePath();
    }




    public Product(String productSaleName, String name, double price, double discountedPrice, String imagePath) {

    }

    public Product(String name, String description, double price, int stock, Category cat) {
    }



    public String getImagePath() {return imagePath;}

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        if (price > 0) {
            this.price = price;
        } else {
            System.out.println("Price must be greater than 0.");
        }
    }

    public int getStockQuantity() {
        return stockQuantity;
    }

    public void setStockQuantity(int stockQuantity) {
        if (stockQuantity >= 0) {
            this.stockQuantity = stockQuantity;
        } else {
            System.out.println("Stock quantity cannot be negative.");
        }
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public void showProducts() {

    }

    @Override
    public String toString() {
        return "Product ID: " + id + ", Name: " + name + ", Description: " + description + ", Price: " + price + "EGP" +
                ", Stock: " + stockQuantity + ", Category: " + category;
    }

}




class Cart {
    private static Cart instance; // Singleton instance
    private static List<Product> items; // Cart items
    private static double totalAmount;
    private static boolean paymentSuccessful;

    // Private constructor to enforce singleton pattern
    Cart() {
        this.items = new ArrayList<>();
        this.totalAmount = 0.0;
        this.paymentSuccessful = false;
    }

    // Get the singleton instance of the Cart
    public static synchronized Cart getInstance() {
        if (instance == null) {
            instance = new Cart();
        }
        return instance;
    }

    // Add an item to the cart
    public static void addItem(Product item) {
            if (item != null && item.getName() != null) {
                items.add(item);
                System.out.println(item.getName() + " added to the cart.");
            } else {
                System.out.println("Cannot add null or invalid product to the cart.");
            }
        }


        // Remove an item from the cart
    public synchronized void removeItem(Product item) {
        if (item == null) {
            throw new IllegalArgumentException("Item cannot be null.");
        }

        if (items.remove(item)) {
            item.setStockQuantity(item.getStockQuantity() + 1); // Restock
            calculateTotal();
            System.out.println("Removed from cart: " + item.getName());
        } else {
            System.out.println("Item not found in cart: " + item.getName());
        }
    }

    // Calculate the total amount of items in the cart
    public static synchronized double calculateTotal() {
        double totalAmount = 0;
        for (Product p : items) {
            if (p instanceof ProductSale) {
                totalAmount += ((ProductSale) p).getDiscountedPrice();
            } else {
                totalAmount += p.getPrice();
            }
        }
        return totalAmount;
    }

    // Clear the cart
    public static synchronized void clearCart() {
        items.forEach(item -> item.setStockQuantity(item.getStockQuantity() + 1)); // Restock all items
        items.clear();
        totalAmount = 0.0;
        paymentSuccessful = false;
        System.out.println("Cart cleared.");
    }

    // Get items in the cart
    public static synchronized List<Product> getItems() {
        return new ArrayList<>(items); // Return a copy of the items list
    }

    // Get total amount
    public synchronized double getTotalAmount() {
        return totalAmount;
    }

    // Check if payment was successful
    public synchronized boolean isPaymentSuccessful() {
        return paymentSuccessful;
    }

    // Process payment
    public synchronized boolean processPayment(PaymentMethod paymentMethod) {
        if (paymentMethod == null) {
            System.out.println("Payment method is not selected.");
            return false;
        }

        paymentSuccessful = paymentMethod.processPayment(totalAmount);
        if (paymentSuccessful) {
            System.out.println("Payment processed successfully!");
        } else {
            System.out.println("Payment failed. Please try again.");
        }
        return paymentSuccessful;
    }

    // PaymentMethod interface
    public interface PaymentMethod {
        boolean processPayment(double amount);
    }

    // Credit card payment implementation
    public static class CreditCardPayment implements PaymentMethod {
        @Override
        public boolean processPayment(double amount) {
            System.out.println("Processing credit card payment for EGP " + amount);
            return true; // Simulate successful payment
        }
    }

    // PayPal payment implementation
    public static class PayPalPayment implements PaymentMethod {
        @Override
        public boolean processPayment(double amount) {
            System.out.println("Processing PayPal payment for EGP " + amount);
            return true; // Simulate successful payment
        }
    }

    // Cash on delivery payment implementation
    public static class CashOnDeliveryPayment implements PaymentMethod {
        @Override
        public boolean processPayment(double amount) {
            System.out.println("Payment will be made upon delivery. Amount: EGP " + amount);
            return true; // Simulate successful Cash on Delivery setup
        }
    }
}







    /*     public static void main(String[] args) {
             Scanner scanner = new Scanner(System.in);
             Cart cart = new Cart();

             System.out.println("WELCOME TO JOUIS VUITTON!");
             System.out.println("--------------------------------------------------");

             // Add items to the cart
             while (true) {
                 System.out.println("Enter the product name (or type 'done' to finish): ");
                 String productName = scanner.nextLine();

                 if (productName.equalsIgnoreCase("done")) {
                     break;
                 }

                 System.out.println("Enter the product price: ");
                 double productPrice;
                 try {
                     productPrice = Double.parseDouble(scanner.nextLine());
                     if (productPrice < 0) {
                         System.out.println("Price cannot be negative. Try again.");
                         continue;
                     }
                 } catch (NumberFormatException e) {
                     System.out.println("Invalid price. Please enter a valid number.");
                     continue;
                 }

                 cart.addItem(new Product(productName, productPrice));
                 System.out.println("Item added to the cart!");
             }

             // Display the total amount in the cart
             System.out.println("Cart Total: EGP " + cart.getTotalAmount());

             // Choose a payment method
             PaymentMethod paymentMethod = null;
             while (paymentMethod == null) {
                 System.out.println("Choose a payment method: ");
                 System.out.println("1. Credit Card");
                 System.out.println("2. PayPal");
                 System.out.println("3. Cash on Delivery");
                 String choice = scanner.nextLine();

                 switch (choice) {
                     case "1":
                         paymentMethod = new CreditCardPayment();
                         break;
                     case "2":
                         paymentMethod = new PayPalPayment();
                         break;
                     case "3":
                         paymentMethod = new CashOnDeliveryPayment();
                         break;
                     default:
                         System.out.println("Invalid choice. Please try again.");
                 }
             }

             // Get customer details
             System.out.println("Enter your name: ");
             String customerName = scanner.nextLine();

             System.out.println("Enter your Address: ");
             String customerAddress = scanner.nextLine();

             // Create an Order
             Order order = new Order("ORD001", cart, paymentMethod, customerName, customerAddress);

             // Confirm Payment
             if (order.confirmPayment()) {
                 System.out.println("Payment confirmed successfully!");
             } else {
                 System.out.println("Payment failed.");
             }

             // Generate and display the invoice
             System.out.println("\n--- order details ---");
             System.out.println(order.generateInvoice());

             scanner.close();
         }
     }*/











