package com.example.jouisvuitton;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.scene.control.ScrollPane;

public class ClothesSaleApp extends Application {
    private Stage mainStage; // Reference to the main stage
    private Cart sharedCart; // Shared cart instance

    // Constructor to pass mainStage and sharedCart
    public ClothesSaleApp(Stage mainStage, Cart sharedCart) {
        this.mainStage = mainStage;
        this.sharedCart = sharedCart;
    }

    // Default constructor for JavaFX compatibility
    public ClothesSaleApp() {}

    @Override
    public void start(Stage primaryStage) {
        // Initialize the database
        Database.initialize();

        // Get screen dimensions
        double screenWidth = Screen.getPrimary().getBounds().getWidth();
        double screenHeight = Screen.getPrimary().getBounds().getHeight();

        // Create the sale title
        Text catchSaleTitle = new Text("Catch our Black Friday Sale up to 60% off!!!!");
        catchSaleTitle.setFont(Font.font("Arial", FontWeight.BOLD, 28));
        catchSaleTitle.setFill(Color.WHITE);
        catchSaleTitle.setWrappingWidth(screenWidth - 100);
        catchSaleTitle.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);

        Rectangle titleBackground = new Rectangle(screenWidth, 60);
        titleBackground.setFill(Color.web("#FFC0CB"));

        StackPane catchSalePane = new StackPane(titleBackground, catchSaleTitle);
        catchSalePane.setAlignment(Pos.CENTER);

        // GridPane to hold the product items
        GridPane gridPane = new GridPane();
        gridPane.setHgap(20);
        gridPane.setVgap(20);
        gridPane.setAlignment(Pos.CENTER);

        int row = 0;
        int col = 0;

        // Dynamically create UI elements for each product on sale
        for (ProductSale productSale : Database.productSales) {
            ImageView productImageView;
            try {
                productImageView = new ImageView(new Image(productSale.getImagePath()));
            } catch (Exception e) {
                productImageView = new ImageView(new Image(Database.defaultImagePath));
            }
            productImageView.setFitWidth(200);
            productImageView.setFitHeight(200);
            productImageView.setPreserveRatio(true);

            Text productLabel = new Text(productSale.getName());
            productLabel.setFont(Font.font("Arial", 16));
            productLabel.setWrappingWidth(200);
            productLabel.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);

            Text productPriceBefore = new Text("Was $" + productSale.getOriginalPrice());
            Text productPriceAfter = new Text("Now $" + productSale.getDiscountedPrice());
            productPriceBefore.setFont(Font.font("Courier New", 12));
            productPriceAfter.setFont(Font.font("Courier New", 12));

            Button addToCartButton = new Button("ADD TO CART");
            addToCartButton.setStyle("-fx-background-color: #008BAA; -fx-text-fill: white; -fx-font-weight: bold;");
            addToCartButton.setMaxWidth(200);

            addToCartButton.setOnAction(e -> {
                if (productSale != null
                        && productSale.getName() != null
                        && productSale.getStockQuantity() > 0
                        && productSale.getDiscountedPrice() > 0) {
                    Product productsale = new ProductSale(
                            productSale.getId(),
                            productSale.getName(),
                            productSale.getDescription(),
                            productSale.getStockQuantity(),
                            productSale.getCategory(),
                            productSale.getImagePath(),
                            productSale.getOriginalPrice(),
                            productSale.getDiscountedPrice()
                    );

                    Cart.getInstance().addItem(productsale); // Add valid product to the cart
                    System.out.println(productsale.getName() + " added to the cart!");
                } else {
                    System.out.println("Cannot add null or invalid product to the cart: " + productSale);
                }
            });




            VBox productVBox = new VBox(10, productLabel, productImageView, productPriceBefore, productPriceAfter, addToCartButton);
            productVBox.setAlignment(Pos.CENTER);

            gridPane.add(productVBox, col, row);

            col++;
            if (col == 3) {
                col = 0;
                row++;
            }
        }

        ScrollPane scrollPane = new ScrollPane(gridPane);
        scrollPane.setFitToWidth(true);
        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.ALWAYS);
        scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);

        Button backToMainButton = new Button("Back to Main");
        backToMainButton.setOnAction(e -> {
            primaryStage.close(); // Close the current stage
            if (mainStage != null) {
                mainStage.show(); // Show the main stage if it's not null
            } else {
                System.out.println("Error: Main stage is not initialized.");
            }
        });


        VBox mainLayout = new VBox(20, catchSalePane, scrollPane, backToMainButton);
        mainLayout.setAlignment(Pos.TOP_CENTER);

        Scene scene = new Scene(mainLayout, screenWidth, screenHeight);
        scene.setFill(Color.WHITE);

        primaryStage.setTitle("Clothing Sale");
        primaryStage.setScene(scene);
        primaryStage.setFullScreen(true);
        primaryStage.show();

    }

    public static void main(String[] args) {
        // Launch the JavaFX application
        launch(args);
    }
}
