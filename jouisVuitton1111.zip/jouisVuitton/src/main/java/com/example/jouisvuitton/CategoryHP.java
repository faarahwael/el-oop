package com.example.jouisvuitton;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.scene.control.ScrollPane;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class CategoryHP extends Application {

        private Scene mainScene; // To store the main scene for back navigation

        @Override
        public void start(Stage primaryStage) {
            Database.initialize();

            List<Category> categories = Database.categories;

            GridPane gridPane = createCategoryGrid(categories, primaryStage);

            ScrollPane scrollPane = new ScrollPane();
            scrollPane.setContent(gridPane);
            scrollPane.setFitToWidth(true);
            scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.ALWAYS);

            mainScene = new Scene(scrollPane, 800, 600);
            primaryStage.setScene(mainScene);
            primaryStage.setTitle("Categories");
            primaryStage.show();
        }

        GridPane createCategoryGrid(List<Category> categories, Stage stage) {
            GridPane gridPane = new GridPane();
            gridPane.setHgap(20);
            gridPane.setVgap(20);
            gridPane.setPadding(new Insets(20));
            gridPane.setAlignment(Pos.CENTER_LEFT);

            int column = 0;
            int row = 0;

            for (Category category : categories) {
                Image image = loadImageWithFallback(category.getImagePath(), "src/products/default.jpg");

                ImageView imageView = new ImageView(image);
                imageView.setFitWidth(150);
                imageView.setFitHeight(150);
                imageView.setPreserveRatio(true);

                Button categoryButton = new Button();
                VBox buttonContent = new VBox(5, imageView, new Label(category.getName()));
                buttonContent.setAlignment(Pos.CENTER);
                categoryButton.setGraphic(buttonContent);

                categoryButton.setStyle("-fx-background-color: transparent; -fx-cursor: hand;");

                categoryButton.setOnMouseEntered(e -> categoryButton.setStyle(
                        "-fx-background-color: rgba(0, 0, 0, 0.3); -fx-cursor: hand;"));
                categoryButton.setOnMouseExited(e -> categoryButton.setStyle(
                        "-fx-background-color: transparent; -fx-cursor: hand;"));

                categoryButton.setOnAction(event -> openCategoryStages(category));

                gridPane.add(categoryButton, column, row);

                column++;
                if (column == 2) {
                    column = 0;
                    row++;
                }
            }

            return gridPane;
        }

        private void openCategoryStages(Category category) {
            Stage categoryStage = new Stage();
            categoryStage.setTitle(category.getName());

            GridPane mainLayout = new GridPane();
            mainLayout.setHgap(20);
            mainLayout.setVgap(20);
            mainLayout.setAlignment(Pos.CENTER);

            Text categoryHeader = new Text("Shop Our Premium " + category.getName() + " Collection!");
            categoryHeader.setFont(Font.font("Arial", 26));

            VBox headerBox = new VBox(10);
            headerBox.setAlignment(Pos.CENTER);
            headerBox.setStyle("-fx-background-color: #FFC0CB; -fx-text-fill: white;");
            headerBox.setPadding(new Insets(20));
            headerBox.getChildren().add(categoryHeader);

            mainLayout.add(headerBox, 0, 0, 3, 1);

            ArrayList<Product> products = category.getProducts();

            for (int i = 0; i < products.size(); i++) {
                Product product = products.get(i);

                VBox productBox = new VBox(20);
                productBox.setAlignment(Pos.CENTER);
                productBox.setStyle("-fx-background-color: #FFF1Fa;");

                File file = new File(product.getImagePath());
                Image image;
                if (file.exists()) {
                    image = new Image(file.toURI().toString());
                } else {
                    image = new Image(new File(Database.defaultImagePath).toURI().toString());
                }

                ImageView imageView = new ImageView(image);
                imageView.setFitWidth(150);
                imageView.setFitHeight(200);
                imageView.setPreserveRatio(true);
                imageView.setSmooth(true);

                Text productName = new Text(product.getName());
                productName.setFont(Font.font("Arial", 18));

                Text productPrice = new Text("Price: " + product.getPrice() + " EGP");
                productPrice.setFont(Font.font("Arial", 16));

                Button addToCartButton = new Button("Add to Cart");

                addToCartButton.setOnAction(e -> {
                    System.out.println("Added to cart: " + product.getName());
                });

                productBox.getChildren().addAll(imageView, productName, productPrice, addToCartButton);

                mainLayout.add(productBox, i % 3, (i / 3) + 1);
            }

            ScrollPane scrollPane = new ScrollPane();
            scrollPane.setContent(mainLayout);
            scrollPane.setFitToWidth(true);

            Scene scene = new Scene(scrollPane, 800, 600);

            categoryStage.setScene(scene);
            categoryStage.setMinWidth(600);
            categoryStage.setMinHeight(400);
            categoryStage.show();
        }

        private Image loadImageWithFallback(String imagePath, String fallbackPath) {
            try {
                return new Image("file:" + imagePath);
            } catch (Exception e) {
                System.out.println("Error loading image: " + imagePath + " | Using fallback.");
                return new Image("file:" + fallbackPath);
            }
        }

        public static void main(String[] args) {
            launch(args);
        }
    }
