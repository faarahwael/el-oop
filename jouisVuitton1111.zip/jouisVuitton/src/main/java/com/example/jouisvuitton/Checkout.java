package com.example.jouisvuitton;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Checkout {

    private static Scene homepageScene; // Reference to the homepage scene

    public static void showCheckoutForm(Stage stage, Scene mainScene) {
        VBox checkoutLayout = new VBox(20);
        checkoutLayout.setPadding(new Insets(20));
        checkoutLayout.setAlignment(Pos.CENTER);
        checkoutLayout.setStyle("-fx-background-color: #FFE4E1;");

        Label formTitle = new Label("Confirm Your Order");
        formTitle.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #D2698E;");

        Label priceLabel = new Label("Total Price: EGP " + String.format("%.2f", Cart.calculateTotal()));
        priceLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #8B0000;");

        TextField nameField = new TextField();
        nameField.setPromptText("Enter your name");

        TextField addressField = new TextField();
        addressField.setPromptText("Enter your address");

        TextField phoneField = new TextField();
        phoneField.setPromptText("Enter your phone number");

        Button confirmButton = new Button("Confirm Order");
        confirmButton.setStyle("-fx-background-color: #FFB6C1; -fx-text-fill: black; -fx-font-weight: bold; -fx-font-size: 16px;");
        confirmButton.setOnAction(e -> {
            String name = nameField.getText();
            String address = addressField.getText();
            String phone = phoneField.getText();

            if (name.isEmpty() || address.isEmpty() || phone.isEmpty()) {
                Alert alert = new Alert(Alert.AlertType.WARNING, "Please fill out all fields before confirming.");
                alert.show();
            } else {
                // Create an Order and store it in the database
                Order newOrder = new Order(
                        "ORD-" + System.currentTimeMillis(),
                        Cart.getItems(),
                        name,
                        address,
                        phone,
                        Cart.calculateTotal()
                );

                // Add the order to the database
                Database.addOrder(newOrder);

                // Log the order addition (debugging purposes)
                System.out.println("Order added to database: " + newOrder);

                // Clear the cart
                Cart.clearCart();

                // Show success message
                Alert successAlert = new Alert(Alert.AlertType.INFORMATION, "Order Confirmed! Thank you.");
                successAlert.show();

                // Transition to the thank you screen
                showThankYouScene(stage, name, mainScene);
            }
        });

        checkoutLayout.getChildren().addAll(formTitle, priceLabel, nameField, addressField, phoneField, confirmButton);
        Scene checkoutScene = new Scene(checkoutLayout, 500, 400);
        stage.setScene(checkoutScene);

        stage.setFullScreen(true);
        stage.setTitle("Checkout");
        stage.show();
    }


    private static void showThankYouScene(Stage stage, String name, Scene mainScene) {
        VBox thankYouLayout = new VBox(20);
        thankYouLayout.setPadding(new Insets(20));
        thankYouLayout.setAlignment(Pos.CENTER);
        thankYouLayout.setStyle("-fx-background-color: #FFE4E1;");

        Label thankYouMessage = new Label("Thank you, " + name + ", for your order!");
        thankYouMessage.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: #D2698E;");

        Button closeButton = new Button("continue shopping");
        closeButton.setStyle("-fx-background-color: #FFB6C1; -fx-text-fill: black; -fx-font-weight: bold;");
        closeButton.setOnAction(event -> {
            stage.setScene(mainScene);
            stage.setTitle("Jouis Vuitton - E-Commerce App");
        });

        thankYouLayout.getChildren().addAll(thankYouMessage, closeButton);

        Scene thankYouScene = new Scene(thankYouLayout, stage.getWidth(), stage.getHeight());
        stage.setScene(thankYouScene);
        stage.setFullScreen(true);
        stage.setTitle("Thank You!");
        stage.show();

        System.out.println("Current Orders: " + Database.getOrders());
    }
}
