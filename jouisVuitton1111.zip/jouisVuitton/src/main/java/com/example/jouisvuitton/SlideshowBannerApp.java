package com.example.jouisvuitton;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SlideshowBannerApp extends Application {

    private int currentIndex = 0; // Track the current banner index
    private Timeline timeline; // For automatic slideshow

    @Override
    public void start(Stage stage) {
        // List of banner images
        List<String> imagePaths = new ArrayList<>();
        imagePaths.add("C:\\Users\\Mirei\\Desktop\\jouisVuitton\\src\\WEB_SALE_UPDATE_19_AUG-29_x840.jpg");
        imagePaths.add("C:\\Users\\Mirei\\Desktop\\jouisVuitton\\src\\Screen-Shot-2017-08-01-at-9.32.00-PM.png");
        imagePaths.add("C:\\Users\\Mirei\\Desktop\\jouisVuitton\\src\\shopping_cart_PNG38.png");

        // Map each banner to a specific page
        Map<Integer, Runnable> bannerActions = new HashMap<>();
        ClothesSaleApp clothesSaleApp = new ClothesSaleApp();
        bannerActions.put(0, () -> clothesSaleApp.start(new Stage()));
        bannerActions.put(1, () -> openPage("Page for Banner 2"));
        bannerActions.put(2, () -> openPage("Page for Banner 3"));

        // ImageView for the banner
        ImageView bannerView = new ImageView();
        bannerView.setPreserveRatio(true);
        bannerView.setFitWidth(800); // Set banner width
        bannerView.setFitHeight(300); // Set banner height

        // Start with the first image
        bannerView.setImage(new Image(imagePaths.get(currentIndex)));

        // Timeline for the automatic slideshow
        timeline = new Timeline(new KeyFrame(Duration.seconds(3), event -> {
            // Move to the next slide
            currentIndex = (currentIndex + 1) % imagePaths.size();
            bannerView.setImage(new Image(imagePaths.get(currentIndex)));
        }));
        timeline.setCycleCount(Timeline.INDEFINITE); // Loop the slideshow
        timeline.play(); // Start the slideshow

        // Navigation buttons
        Button prevButton = new Button("⟨"); // Left arrow
        Button nextButton = new Button("⟩"); // Right arrow

        prevButton.setOnAction(event -> {
            // Pause the timeline when user interacts
            timeline.pause();
            currentIndex = (currentIndex - 1 + imagePaths.size()) % imagePaths.size();
            bannerView.setImage(new Image(imagePaths.get(currentIndex)));
        });

        nextButton.setOnAction(event -> {
            // Pause the timeline when user interacts
            timeline.pause();
            currentIndex = (currentIndex + 1) % imagePaths.size();
            bannerView.setImage(new Image(imagePaths.get(currentIndex)));
        });

        // Handle mouse clicks on the banner
        bannerView.setOnMouseClicked(event -> {
            // Execute the corresponding action for the current banner
            if (bannerActions.containsKey(currentIndex)) {
                bannerActions.get(currentIndex).run();
            }
        });

        // Navigation layout
        HBox navButtons = new HBox(10, prevButton, nextButton);
        navButtons.setAlignment(javafx.geometry.Pos.CENTER);

        // Layout
        BorderPane root = new BorderPane();
        root.setCenter(bannerView);
        root.setBottom(navButtons);

        Scene scene = new Scene(root, 800, 400);
        stage.setTitle("Slideshow Banner with Controls");
        stage.setScene(scene);
        stage.show();
    }

    // Simulate opening a new page
    private void openPage(String pageName) {
        Stage newStage = new Stage();
        StackPane root = new StackPane(new Label(pageName));
        Scene scene = new Scene(root, 400, 200);
        newStage.setTitle(pageName);
        newStage.setScene(scene);
        newStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
