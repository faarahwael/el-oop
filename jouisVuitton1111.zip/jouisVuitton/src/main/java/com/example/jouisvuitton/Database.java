package com.example.jouisvuitton;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Database {

    // Static data storage
    public static List<Product> products = new ArrayList<>();
    public static List<Category> categories = new ArrayList<>();
    public static List<Order> orders = new ArrayList<>();
    public static List<ProductSale> productSales = new ArrayList<>();
    public static List<Customer> customers = new ArrayList<>();
    public static List<Admin> admins = new ArrayList<>();

    // Default image path
    public static final String defaultImagePath = "src/product_images/default.jpg";

    // Initialization flag
    private static boolean isInitialized = false;

    // Initialize database with default data
    public static void initialize() {
        if (isInitialized) return;

        // Create Categories
        Category c1 = new Category("Bags", "Women bags", "C:/Users/Mirei/Desktop/jouisVuitton/src/product_images/bags/little black bag.jpg");
        Category c2 = new Category("Shirts", "Your everyday needs with love", "C:/Users/Mirei/Desktop/jouisVuitton/src/product_images/shirts/our famous Retro Jersey.jpg");
        Category c3 = new Category("Dresses", "Elegant dresses", "C:/Users/Mirei/Desktop/jouisVuitton/src/product_images/dresses/ICONIC Gold dress.jpg");
        Category c4 = new Category("Sweatshirts", "Cozy winter wear", "C:/Users/Mirei/Desktop/jouisVuitton/src/sweatshirt/Cropx.jpg");
        Category c5 = new Category("In Sale", "Products with up to 70% sale", "C:/Users/Mirei/Desktop/jouisVuitton/src/R-removebg-preview.png");
        Category c6 = new Category("Pants", "Your favorite pants", "C:/Users/Mirei/Desktop/jouisVuitton/src/pants/IMG-20241214-WA0061.jpg");

        // Add Categories
        addCategory(c1);
        addCategory(c2);
        addCategory(c3);
        addCategory(c4);
        addCategory(c5);
        addCategory(c6);

        // Create Products and Add to Categories
        addProductToCategory(new Product("1b", "Majestic White Bag", "White hand bag with brown straps", 100, c1, 890, "C:/Users/Mirei/Desktop/jouisVuitton/src/product_images/bags/majestic white bag.jpg"), c1);
        addProductToCategory(new Product("2b", "Simple Burgundy Bag", "Burgundy hand bag with gold accessories", 70, c1, 900, "C:/Users/Mirei/Desktop/jouisVuitton/src/product_images/bags/simple Burgandy bag.jpg"), c1);
        addProductToCategory(new Product("3b", "The Famous Burgundy Bag", "Small burgundy bag with crocodile pattern", 50, c1, 780, "C:/Users/Mirei/Desktop/jouisVuitton/src/product_images/bags/The Famous Burgandy bag.jpg"), c1);
        addProductToCategory(new Product("4b", "Little Black Bag", "Black shoulder bag", 100, c1, 1000, "C:/Users/Mirei/Desktop/jouisVuitton/src/product_images/bags/little black bag.jpg"), c1);
        addProductToCategory(new Product("5b", "Little Burgundy Bag", "Burgundy shoulder bag", 100, c1, 1000, "C:/Users/Mirei/Desktop/jouisVuitton/src/product_images/bags/little burgandy bag.jpg"), c1);

        addProductToCategory(new Product("1t", "Our Famous Retro Jersey", "Oversized white polo shirt", 20, c2, 700, "C:/Users/Mirei/Desktop/jouisVuitton/src/product_images/shirts/our famous Retro Jersey.jpg"), c2);
        addProductToCategory(new Product("2t", "The NFL Jersey", "Boxy Fit BLACK X PINK", 70, c2, 750, "C:/Users/Mirei/Desktop/jouisVuitton/src/product_images/shirts/THE NFL jersey.jpg"), c2);
        addProductToCategory(new Product("3t", "Navy Blue Basic Top", "Short sleeve basic top", 40, c2, 499, "C:/Users/Mirei/Desktop/jouisVuitton/src/product_images/shirts/navy blue basic top.jpg"), c2);
        addProductToCategory(new Product("4t", "Pinky Round Neck", "Short sleeve basic top", 55, c2, 650, "C:/Users/Mirei/Desktop/jouisVuitton/src/product_images/shirts/pinky round neck.jpg"), c2);
        addProductToCategory(new Product("5t", "Grey Basic Round Neck", "Short sleeve basic top", 60, c2, 550, "C:/Users/Mirei/Desktop/jouisVuitton/src/product_images/shirts/grey basic round neck.jpg"), c2);

        addProductToCategory(new Product("1d", "Black and White Queen Dress", "Long one-shoulder black X white dress", 8, c3, 11000, "C:/Users/Mirei/Desktop/jouisVuitton/src/product_images/dresses/Black and white QUEEN dress.jpg"), c3);
        addProductToCategory(new Product("2d", "Baby Blue Mermaid Dress", "Long baby blue dress", 4, c3, 15000, "C:/Users/Mirei/Desktop/jouisVuitton/src/product_images/dresses/Baby blue mermaid dress.jpg"), c3);
        addProductToCategory(new Product("3d", "Lavender Bloom Dress", "Long strapless satin dress", 3, c3, 16000, "C:/Users/Mirei/Desktop/jouisVuitton/src/product_images/dresses/Lavender Bloom dress.jpg"), c3);
        addProductToCategory(new Product("4d", "Hawaiian Princess Dress", "Long strapless dress in orange and black", 7, c3, 9500, "C:/Users/Mirei/Desktop/jouisVuitton/src/product_images/dresses/hawaiian princess dress.jpg"), c3);
        addProductToCategory(new Product("5d", "Little White Dress", "Short floral dress", 5, c3, 7500, "C:/Users/Mirei/Desktop/jouisVuitton/src/product_images/dresses/Little white dress.jpg"), c3);
        addProductToCategory(new Product("6d", "Lemon Spice Dress", "Long yellow off-shoulder dress", 3, c3, 10000, "C:/Users/Mirei/Desktop/jouisVuitton/src/product_images/dresses/Lemon Spice dress.jpg"), c3);
        addProductToCategory(new Product("7d", "Iconic Gold Dress", "Powerful gold long dress", 3, c3, 20000, "C:/Users/Mirei/Desktop/jouisVuitton/src/product_images/dresses/ICONIC Gold dress.jpg"), c3);

        addProductToCategory(new Product("1s", "Our Special Crop", "The perfect crop", 50, c4, 670, "C:/Users/Mirei/Desktop/jouisVuitton/src/sweatshirt/Cropx.jpg"), c4);
        addProductToCategory(new Product("2s", "Basic Grey Hoodie", "Grey cropped hoodie", 88, c4, 500, "C:/Users/Mirei/Desktop/jouisVuitton/src/sweatshirt/basic grey.jpg"), c4);
        addProductToCategory(new Product("3s", "Navy Blue Hoodie", "Yellow and navy combo", 80, c4, 700, "C:/Users/Mirei/Desktop/jouisVuitton/src/sweatshirt/navyStrikeit.jpg"), c4);
        addProductToCategory(new Product("4s", "Grey on Black Jacket", "Your favorite puff print jacket", 20, c4, 800, "C:/Users/Mirei/Desktop/jouisVuitton/src/sweatshirt/sn2 jacket.jpg"), c4);

        addProductToCategory(new Product("1p", "Baggy Jeans", "Light blue pants", 70, c6, 799, "C:/Users/Mirei/Desktop/jouisVuitton/src/pants/IMG-20241214-WA0059.jpg"), c6);
        addProductToCategory(new Product("2p", "Washed Baggy", "Dirty baggy jeans", 50, c6, 899, "C:/Users/Mirei/Desktop/jouisVuitton/src/pants/IMG-20241214-WA0060.jpg"), c6);
        addProductToCategory(new Product("3p", "Dark Baggy", "Dark blue baggy jeans", 88, c6, 850, "C:/Users/Mirei/Desktop/jouisVuitton/src/pants/IMG-20241214-WA0061.jpg"), c6);

        // Add Sale Products
        productSales.add(new ProductSale("S0", "Blue Shirt", "Basic short sleeve top", 40, c5,
                "C:/Users/Mirei/Desktop/jouisVuitton/src/product_images/shirts/blue top.jpg", 800, 499));

        productSales.add(new ProductSale("S1", "Signature Grey Knitted Set", "Grey soft knit", 30, c5,
                "C:/Users/Mirei/Desktop/jouisVuitton/src/sets/WhatsApp Image 2024-12-14 at 16.21.57_7d7bd492.jpg", 2000, 1599));

        ProductSale p24 = new ProductSale("s2", "pink shirt", "cotton basic top", 20, c5,
                "C:/Users/Mirei/Desktop/jouisVuitton/src/product_images/shirts/pinky round neck.jpg", 800, 499);

        ProductSale p25 = new ProductSale("s3", "Signature black knitted set", "black soft knit", 30, c5,
                "C:/Users/Mirei/Desktop/jouisVuitton/src/sets/WhatsApp Image 2024-12-14 at 16.23.01_d1b6362b.jpg", 2000, 1599);

        ProductSale p26 = new ProductSale("s4", "everyday pants", "wideleg sweats", 40, c5,
                "C:/Users/Mirei/Desktop/jouisVuitton/src/pants/WhatsApp Image 2024-12-14 at 16.15.02_8a20ec8a.jpg", 900, 599);

        ProductSale p27 = new ProductSale("s5", "beige yogas", "comfiest yoga pants", 50, c5,
                "C:/Users/Mirei/Desktop/jouisVuitton/src/pants/WhatsApp Image 2024-12-14 at 16.43.55_ea3aea6d.jpg", 600, 399);

        ProductSale p28 = new ProductSale("s6", "brown knitted pullover", "comfiest knit", 45, c5,
                "C:/Users/Mirei/Desktop/jouisVuitton/src/sweatshirt/brown knit.jpg", 1000, 699);

        ProductSale p29 = new ProductSale("s7", "the Famous Burgandy Bag", "our Famous burgandy bag", 36, c5,
                "C:/Users/Mirei/Desktop/jouisVuitton/src/product_images/bags/The Famous Burgandy bag.jpg", 780, 600);

        ProductSale p30 = new ProductSale("s8", "the olive Basic", "comfiest tank top", 77, c5,
                "C:/Users/Mirei/Desktop/jouisVuitton/src/product_images/shirts/tanktop.jpg", 700, 400);


        productSales.add(p24);
        productSales.add(p25);
        productSales.add(p26);
        productSales.add(p27);
        productSales.add(p28);
        productSales.add(p29);
        productSales.add(p30);


        Admin admin = new Admin("mireilleamir","0000","admin",12);
        Admin admin1 = new Admin("jadaahmed","0000","admin",10);
        Admin admin2 = new Admin("farahwael","0000","admin",11);
        Admin admin3 = new Admin("hanasalah","0000","admin",9);
        Admin admin4 = new Admin("joumana","0000","admin",10);

        Customer customer= new Customer("mazentarek","1111",12000,"tagamoaa", User.Gender.MALE,"clothes");
        Customer customer1= new Customer("ahmedHossam","1111",1000,"tagamoaa", User.Gender.MALE,"clothes");
        Customer customer2= new Customer("mahmoudsoheil","1111",1400,"zayed", User.Gender.MALE,"clothes");
        Customer customer3= new Customer("mahmoudkhalil","1111",20000,"madinet nasr", User.Gender.MALE,"clothes");

        addAdmin(admin);
        addAdmin(admin1);
        addAdmin(admin2);
        addAdmin(admin3);
        addAdmin(admin4);

        addCustomer(customer);
        addCustomer(customer1);
        addCustomer(customer2);
        addCustomer(customer3);




        isInitialized = true;
    }

    // Add a product and associate with a category
    public static void addProductToCategory(Product product, Category category) {
        products.add(product);
        category.addProduct(product);
    }

    // Add a category
    public static void addCategory(Category category) {
        categories.add(category);
    }

    // Add a customer
    public static void addCustomer(Customer customer) {
        customers.add(customer);
    }

    // Add an admin
    public static void addAdmin(Admin admin) {
        admins.add(admin);
    }

    // Retrieve all products
    public static List<Product> getProducts() {
        return products;
    }

    // Retrieve all categories
    public static List<Category> getCategories() {
        return categories;
    }

    // Retrieve all customers
    public static List<Customer> getCustomers() {
        return customers;
    }

    // Retrieve all admins
    public static List<Admin> getAdmins() {
        return admins;
    }

    // Retrieve all orders
    public static List<Order> getOrders() {
        return orders;
    }

    // Add a new order
    public static void addOrder(Order order) {
        orders.add(order);
    }

    // Find a product by ID
    public static Product findProductById(String productId) {
        return products.stream()
                .filter(product -> product.getId().equals(productId))
                .findFirst()
                .orElse(null);
    }


    public static Admin findAdminByCredentials(String username, String password) {
        return admins.stream()
                .filter(admin -> admin.getUsername().equals(username) && admin.getPassword().equals(password))
                .findFirst()
                .orElse(null);
    }

    public static Customer findCustomerByCredentials(String username, String password) {
        return customers.stream()
                .filter( Customer -> Customer.getUsername().equals(username) && Customer.getPassword().equals(password))
                .findFirst()
                .orElse(null);
    }
}
