package com.example.jouisvuitton;

import java.util.List;

public class Order {
    private String orderId;
    private String customerName;
    private String customerAddress;
    private String customerPhone;
    private List<Product> products;
    private double totalAmount;
    private OrderStatus status;

    public Order(String customerName, String customerAddress, String customerPhone, List<Product> products, double totalAmount) {
        if (customerName == null || customerName.isEmpty()) {
            throw new IllegalArgumentException("Customer name cannot be null or empty.");
        }
        if (customerAddress == null || customerAddress.isEmpty()) {
            throw new IllegalArgumentException("Customer address cannot be null or empty.");
        }
        if (customerPhone == null || customerPhone.isEmpty()) {
            throw new IllegalArgumentException("Customer phone cannot be null or empty.");
        }
        if (products == null || products.isEmpty()) {
            throw new IllegalArgumentException("Order must contain at least one product.");
        }
        if (totalAmount <= 0) {
            throw new IllegalArgumentException("Total amount must be greater than zero.");
        }

        this.orderId = generateOrderId();
        this.customerName = customerName;
        this.customerAddress = customerAddress;
        this.customerPhone = customerPhone;
        this.products = products;
        this.totalAmount = totalAmount;
        this.status = OrderStatus.PENDING;
    }

    public Order(String customerName, List<Product> items, String name, String address, String phone, double v) {
    }


    private String generateOrderId() {
        // Simple order ID generation logic (you can replace this with more sophisticated logic if needed)
        return "ORD-" + System.currentTimeMillis();
    }

    public boolean confirmPayment(Cart.PaymentMethod paymentMethod) {
        if (paymentMethod == null) {
            throw new IllegalArgumentException("Payment method cannot be null.");
        }
        if (paymentMethod.processPayment(totalAmount)) {
            status = OrderStatus.CONFIRMED;
            return true;
        }
        return false;
    }

    public String generateInvoice() {
        StringBuilder invoice = new StringBuilder();
        invoice.append("Order ID: ").append(orderId).append("\n");
        invoice.append("Customer: ").append(customerName).append("\n");
        invoice.append("Address: ").append(customerAddress).append("\n");
        invoice.append("Phone: ").append(customerPhone).append("\n");
        invoice.append("Total: EGP ").append(String.format("%.2f", totalAmount)).append("\n");
        invoice.append("Status: ").append(status).append("\n");
        invoice.append("Products:\n");

        for (Product product : products) {
            invoice.append("- ").append(product.getName()).append(" (EGP ").append(product.getPrice()).append(")\n");
        }

        return invoice.toString();
    }

    // Getters for all fields (if needed)
    public String getOrderId() {
        return orderId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getCustomerAddress() {
        return customerAddress;
    }

    public String getCustomerPhone() {
        return customerPhone;
    }

    public List<Product> getProducts() {
        return products;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public OrderStatus getStatus() {
        return status;
    }



}
