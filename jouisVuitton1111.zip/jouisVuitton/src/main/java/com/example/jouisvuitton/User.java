package com.example.jouisvuitton;


import java.util.List;
import java.util.Scanner;

public class User {
    public String username;
    public String password;
    public double balance;
    public String address;
    public String role;
    public int workingHours;
    public String interests;

    public enum Gender { FEMALE, MALE }
    public Gender gender;

    public User() {}

    public User(String username, String password, double balance,
                String address, Gender gender, String interests) {
        this.username = username;
        this.password = password;
        this.balance = balance;
        this.address = address;
        this.gender = gender;
        this.interests = interests;
    }


    public String getUsername() { return username; }
    public void setUsername(String username) {
        if (username == null || username.trim().isEmpty()) {
            throw new IllegalArgumentException("Username cannot be empty or null.");
        }
        this.username = username;
    }

    public String getPassword() { return password; }
    public void setPassword(String password) {
        if (password == null || password.length() < 6) {
            throw new IllegalArgumentException("Password must be at least 6 characters long.");
        }
        this.password = password;
    }

    public double getBalance() { return balance; }
    public void setBalance(double balance) {
        if (balance < 0) {
            throw new IllegalArgumentException("Balance cannot be negative.");
        }
        this.balance = balance;
    }


    public String getAddress() { return address; }
    public void setAddress(String address) {
        if (address == null || address.trim().isEmpty()) {
            throw new IllegalArgumentException("Address cannot be empty.");
        }
        this.address = address;
    }

    public Gender getGender() { return gender; }
    public void setGender(Gender gender) {
        if (gender == null) {
            throw new IllegalArgumentException("Gender cannot be null.");
        }
        this.gender = gender;
    }

    public String getInterests() { return interests; }
    public void setInterests(String interests) {
        if (interests == null || interests.trim().isEmpty()) {
            throw new IllegalArgumentException("Interests cannot be empty or null.");
        }
        this.interests = interests;
    }
}

class Customer extends User {
    public Customer() {}

    public Customer(String username, String password, double balance,
                    String address, Gender gender, String interests) {
        super(username, password, balance, address, gender, interests);
    }

    public static void main(String[] args) {
        Customer c1 = new Customer();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            try {
                System.out.println("Please enter your username: ");
                String newUsername = scanner.nextLine();
                c1.setUsername(newUsername);
                System.out.println("Current Username: " + c1.getUsername());
                break;
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }

        while (true) {
            try {
                System.out.println("Please enter your password: ");
                String newPassword = scanner.nextLine();
                c1.setPassword(newPassword);
                System.out.println("Current Password: " + c1.getPassword());
                break;
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }

        while (true) {
            try {
                System.out.println("Please enter your current balance: ");
                double newBalance = Double.parseDouble(scanner.nextLine());
                c1.setBalance(newBalance);
                System.out.println("Current Balance: " + c1.getBalance());
                break;
            } catch (IllegalArgumentException e) {
                System.out.println("Error: Balance must be a valid non-negative number.");
            }
        }


        while (true) {
            try {
                System.out.println("Please enter your gender (FEMALE/MALE): ");
                String genderInput = scanner.nextLine().toUpperCase();
                Gender newGender = Gender.valueOf(genderInput);
                c1.setGender(newGender);
                System.out.println("Updated Gender: " + c1.getGender());
                break;
            } catch (IllegalArgumentException e) {
                System.out.println("Error: Invalid gender. Please enter FEMALE or MALE.");
            }
        }

        while (true) {
            try {
                System.out.println("Please enter your interests: ");
                String newInterests = scanner.nextLine();
                c1.setInterests(newInterests);
                System.out.println("Interests: " + c1.getInterests());
                break;
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }

        while (true) {
            try {
                System.out.println("Please enter your address: ");
                String newAddress = scanner.nextLine();
                c1.setAddress(newAddress);
                System.out.println("Address: " + c1.getAddress());
                break;
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }

        scanner.close();
    }
}

class InvalidUserInputException extends Exception{
    public InvalidUserInputException(String message){
        super(message);
    }
}

class ProductNotFoundException extends Exception{
    public ProductNotFoundException (String message){
        super(message);
    }
}

class OrderNotFoundException extends Exception{
    public OrderNotFoundException (String message){
        super(message);
    }
}

class UnauthorizedAccessException extends Exception {
    public UnauthorizedAccessException(String message){
        super(message);
    }
}

class Admin extends User {
    private String username;
    private String password;
    private String role;
    private int workingHours;

    public Admin(String username, String password, String role, int workingHours) {
        this.username = username;
        this.password = password;
        this.role = role;
        this.workingHours = workingHours;
    }

    public Admin() {

    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        if (username == null || username.trim().isEmpty()) {
            throw new IllegalArgumentException("Username cannot be empty or null.");
        }
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        if (password == null || password.length() < 6) {
            throw new IllegalArgumentException("Password must be at least 6 characters long.");
        }
        this.password = password;
    }


    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public int getWorkingHours() {
        return workingHours;
    }

    public void setWorkingHours(int workingHours) {
        this.workingHours = workingHours;
    }

    @Override
    public String toString() {
        return "Admin{" + "username='" + username + '\''
                + ", role='" + '\'' + ", workingHours="
                + workingHours;
    }

    public boolean verifyPassword(String inputPassword) {
        return this.password.equals(inputPassword);
    }
}


class AdminDashboard{

    public void showAllUsers(List<User> users) throws InvalidUserInputException{
        if (users == null || users.isEmpty()) {
            throw new InvalidUserInputException("No users available to display.");
        }
        System.out.println("Users:");
        for (User user : users) {
            System.out.println(user);
        }
    }

    public void showAllProducts(List<Product> products) throws ProductNotFoundException{
        if (products == null || products.isEmpty()) {
            throw new ProductNotFoundException("No products available to display.");
        }
        System.out.println("Products:");
        for (Product product : products) {
            System.out.println(product);
        }
    }

    public void showAllOrders(List<Order> orders) throws OrderNotFoundException{
        if (orders == null || orders.isEmpty()) {
            throw new OrderNotFoundException("No orders available to display.");
        }
        System.out.println("Orders:");
        for (Order order : orders) {
            System.out.println(order);
        }
    }

}
