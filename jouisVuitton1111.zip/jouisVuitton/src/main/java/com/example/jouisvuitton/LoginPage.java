package com.example.jouisvuitton;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class LoginPage extends Application {
    @Override
    public void start(Stage primaryStage) {
        // Ensure the database is initialized
        Database.initialize();

        primaryStage.setTitle("Login Page");

        StackPane login = new StackPane();
        login.setStyle("-fx-background-color: #f9dbe5; -fx-padding: 20;");

        GridPane loginPane = new GridPane();
        loginPane.setHgap(10);
        loginPane.setVgap(15);
        loginPane.setAlignment(Pos.CENTER);

        Label usernameL = new Label("Username:");
        usernameL.setFont(Font.font("Times New Roman", 18));
        TextField usernameTF = new TextField();

        Label passwordL = new Label("Password:");
        passwordL.setFont(Font.font("Times New Roman", 18));
        PasswordField passwordTF = new PasswordField();

        Button loginB = new Button("Login");
        loginB.setFont(Font.font("Times New Roman", 18));
        loginB.setStyle("-fx-background-color: #c4a7b3; -fx-text-fill: white;");
        loginB.setOnAction(e -> {
            String username = usernameTF.getText().trim();
            String password = passwordTF.getText().trim();

            // Check if the user is an admin
            Admin admin = Database.findAdminByCredentials(username, password);
            if (admin != null) {
                openAdminsDashboard(primaryStage);
                return;
            }

            // Check if the user is a customer
            Customer customer = Database.findCustomerByCredentials(username, password);
            if (customer != null) {
                openHomePage(primaryStage, customer);
                return;
            }

            // If no match, show an error
            showErrorMessage("Invalid credentials. Please try again.");
        });

        loginPane.add(usernameL, 0, 0);
        loginPane.add(usernameTF, 1, 0);
        loginPane.add(passwordL, 0, 1);
        loginPane.add(passwordTF, 1, 1);
        loginPane.add(loginB, 1, 2);

        Image loginImage = new Image("file:C:\\Users\\Mirei\\Desktop\\jouisVuitton\\src\\theme\\jvpink.jpg");
        ImageView lImageView = new ImageView(loginImage);
        lImageView.setFitHeight(210);
        lImageView.setFitWidth(210);

        VBox loginVBox = new VBox(20, lImageView, loginPane);
        loginVBox.setAlignment(Pos.TOP_CENTER);

        login.getChildren().add(loginVBox);

        Scene loginScene = new Scene(login, 600, 400);
        primaryStage.setScene(loginScene);

        // Enable full-screen mode
        primaryStage.setFullScreen(true);

        primaryStage.show();
    }

    private void openAdminsDashboard(Stage primaryStage) {
        AdminsDashboard adminsDashboard = new AdminsDashboard();
        try {
            adminsDashboard.start(primaryStage);
        } catch (Exception e) {
            showErrorMessage("Failed to load Admin Dashboard.");
        }
    }

    private void openHomePage(Stage primaryStage, Customer customer) {
        // Redirect to JouisVuittonECommerceApp for customers
        JouisVuittonECommerceApp ecommerceApp = new JouisVuittonECommerceApp();
        try {
            ecommerceApp.start(primaryStage);
        } catch (Exception e) {
            showErrorMessage("Failed to load the homepage.");
        }
    }

    private void showErrorMessage(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Login Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
