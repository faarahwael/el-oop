package com.example.jouisvuitton;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class saleBanner extends Application {

        @Override
        public void start(Stage stage) {
            // Load the image
            Image image = new Image("C:\\Users\\Mirei\\Desktop\\jouisVuitton\\src\\Sale.jpeg");

            // Create an ImageView
            ImageView imageView = new ImageView(image);
            imageView.setFitWidth(400);   // Set the desired width
            imageView.setFitHeight(300); // Set the desired height
            imageView.setPreserveRatio(true); // Preserve the aspect ratio

            // Add the ImageView to a layout
            VBox layout = new VBox();
            layout.getChildren().add(imageView);

            // Create the Scene
            Scene scene = new Scene(layout, 400, 400);

            // Configure the Stage
            stage.setTitle("Display Image Example");
            stage.setScene(scene);
            stage.show();
        }

        public static void main(String[] args) {
            launch(args);
        }
    }


