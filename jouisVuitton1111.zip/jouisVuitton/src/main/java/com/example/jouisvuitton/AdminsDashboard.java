package com.example.jouisvuitton;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class AdminsDashboard extends Application {

    @Override
    public void start(Stage stage) {
        Database.initialize(); // Ensure the database is initialized

        GridPane gridLayout = new GridPane();
        gridLayout.setPadding(new Insets(50));
        gridLayout.setHgap(20); // Horizontal gap between buttons
        gridLayout.setVgap(20); // Vertical gap between rows
        gridLayout.setAlignment(Pos.CENTER);
        gridLayout.setStyle("-fx-background-color: #fff0f6;"); // Light pink background

        Label title = new Label("Admin Dashboard");
        title.setStyle("-fx-font-size: 36px; -fx-font-weight: bold; -fx-text-fill: #d63384;"); // Glittery pink text

        // Buttons
        Button addProductButton = createStyledButton("Add Product");
        addProductButton.setOnAction(e -> openAddProductWindow(stage));

        Button removeProductButton = createStyledButton("Remove Product");
        removeProductButton.setOnAction(e -> openRemoveProductWindow(stage));

        Button viewAllProductsButton = createStyledButton("View All Products");
        viewAllProductsButton.setOnAction(e -> openViewProductWindow(stage));

        Button viewStockButton = createStyledButton("View Stock");
        viewStockButton.setOnAction(e -> openStockWindow(stage));

        Button viewOrdersButton = createStyledButton("View Orders");
        viewOrdersButton.setOnAction(e -> openOrdersWindow(stage));

        // Adding buttons to the grid
        gridLayout.add(addProductButton, 0, 0); // First row, first column
        gridLayout.add(removeProductButton, 1, 0); // First row, second column
        gridLayout.add(viewAllProductsButton, 0, 1); // Second row, first column
        gridLayout.add(viewStockButton, 1, 1); // Second row, second column
        gridLayout.add(viewOrdersButton, 0, 2); // Third row, first column

        // Add title above the grid
        VBox rootLayout = new VBox(20);
        rootLayout.setAlignment(Pos.TOP_CENTER);
        rootLayout.getChildren().addAll(title, gridLayout);

        Scene scene = new Scene(rootLayout, 800, 600);
        stage.setScene(scene);
        stage.setTitle("Admin Dashboard");
        stage.setFullScreen(true); // Full-screen mode
        stage.show();
    }

    private Button createStyledButton(String text) {
        Button button = new Button(text);
        button.setStyle(
                "-fx-background-color: linear-gradient(to right, #ff99cc, #ff66b2, #ff80bf);" +
                        "-fx-text-fill: white;" +
                        "-fx-font-size: 20px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 0;" +
                        "-fx-border-radius: 0;" +
                        "-fx-border-color: #d63384;" +
                        "-fx-border-width: 2;" +
                        "-fx-cursor: hand;"
        );

        // Set square dimensions
        double buttonSize = 200; // Size for width and height
        button.setPrefWidth(buttonSize);
        button.setPrefHeight(buttonSize);

        button.setOnMouseEntered(e -> button.setStyle(
                "-fx-background-color: linear-gradient(to right, #cc80a3, #b35d91, #bf6fa0);" + // Darkened effect
                        "-fx-text-fill: white;" +
                        "-fx-font-size: 20px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 0;" +
                        "-fx-border-radius: 0;" +
                        "-fx-border-color: #d63384;" +
                        "-fx-border-width: 2;" +
                        "-fx-cursor: hand;"
        ));

        button.setOnMouseExited(e -> button.setStyle(
                "-fx-background-color: linear-gradient(to right, #ff99cc, #ff66b2, #ff80bf);" +
                        "-fx-text-fill: white;" +
                        "-fx-font-size: 20px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 0;" +
                        "-fx-border-radius: 0;" +
                        "-fx-border-color: #d63384;" +
                        "-fx-border-width: 2;" +
                        "-fx-cursor: hand;"
        ));

        return button;
    }

    private Button createFramelessBackButton(Stage currentStage, Stage parentStage) {
        Button backButton = new Button("← Back");
        backButton.setStyle("-fx-background-color: transparent; -fx-text-fill: #d63384; -fx-font-size: 16px; -fx-underline: true; -fx-cursor: hand;");
        backButton.setOnAction(e -> {
            currentStage.close();
            parentStage.show();
        });
        return backButton;
    }

    private Label createBackLabel(Stage currentStage, Stage parentStage) {
        Label backLabel = new Label("Back");
        backLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: #d63384; -fx-underline: true; -fx-cursor: hand;");
        backLabel.setOnMouseClicked(e -> {
            currentStage.close();
            parentStage.show();
        });
        return backLabel;
    }

    private void openAddProductWindow(Stage parentStage) {
        Stage addProductStage = new Stage();
        VBox layout = new VBox(20);
        layout.setPadding(new Insets(30));
        layout.setAlignment(Pos.CENTER);

        Label title = new Label("Add New Product");
        title.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #d63384;");

        TextField idField = new TextField();
        idField.setPromptText("Product ID");

        TextField nameField = new TextField();
        nameField.setPromptText("Product Name");

        TextField descriptionField = new TextField();
        descriptionField.setPromptText("Product Description");

        TextField priceField = new TextField();
        priceField.setPromptText("Price");

        TextField stockField = new TextField();
        stockField.setPromptText("Stock Quantity");

        ComboBox<Category> categoryComboBox = new ComboBox<>();
        categoryComboBox.getItems().addAll(Database.getCategories());
        categoryComboBox.setPromptText("Select Category");

        Button addButton = createStyledButton("Add Product");
        addButton.setOnAction(e -> {
            try {
                String id = idField.getText();
                String name = nameField.getText();
                String description = descriptionField.getText();
                double price = Double.parseDouble(priceField.getText());
                int stock = Integer.parseInt(stockField.getText());
                Category category = categoryComboBox.getValue();

                if (category == null) throw new Exception("Please select a category.");

                Product product = new Product(id, name, description, stock, category, price, Database.defaultImagePath);
                Database.addProductToCategory(product, category);

                Alert successAlert = new Alert(Alert.AlertType.INFORMATION, "Product added successfully!");
                successAlert.show();
                addProductStage.close();
            } catch (Exception ex) {
                Alert errorAlert = new Alert(Alert.AlertType.ERROR, "Failed to add product. " + ex.getMessage());
                errorAlert.show();
            }
        });

        Label backLabel = createBackLabel(addProductStage, parentStage);

        layout.getChildren().addAll(title, idField, nameField, descriptionField, priceField, stockField, categoryComboBox, addButton, backLabel);

        Scene scene = new Scene(layout, 500, 400);
        addProductStage.setScene(scene);
        addProductStage.setTitle("Add Product");
        addProductStage.setFullScreen(true);
        addProductStage.show();
        parentStage.hide();
    }


    private void openRemoveProductWindow(Stage parentStage) {
        Stage removeProductStage = new Stage();
        VBox layout = new VBox(20);
        layout.setPadding(new Insets(30));
        layout.setAlignment(Pos.CENTER);

        Label title = new Label("Remove Product");
        title.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #d63384;");

        TextField productIdField = new TextField();
        productIdField.setPromptText("Enter Product ID");

        Button removeButton = createStyledButton("Remove Product");
        removeButton.setOnAction(e -> {
            try {
                String productId = productIdField.getText();
                Product product = Database.findProductById(productId);

                if (product != null) {
                    Database.getProducts().remove(product);
                    product.getCategory().getProducts().remove(product);

                    Alert successAlert = new Alert(Alert.AlertType.INFORMATION, "Product removed successfully!");
                    successAlert.show();
                    removeProductStage.close();
                } else {
                    Alert errorAlert = new Alert(Alert.AlertType.ERROR, "Product not found.");
                    errorAlert.show();
                }
            } catch (Exception ex) {
                Alert errorAlert = new Alert(Alert.AlertType.ERROR, "Failed to remove product. " + ex.getMessage());
                errorAlert.show();
            }
        });

        Label backLabel = createBackLabel(removeProductStage, parentStage);

        layout.getChildren().addAll(title, productIdField, removeButton, backLabel);

        Scene scene = new Scene(layout, 500, 300);
        removeProductStage.setScene(scene);
        removeProductStage.setTitle("Remove Product");
        removeProductStage.setFullScreen(true);
        removeProductStage.show();
        parentStage.hide();
    }


    private void openViewProductWindow(Stage parentStage) {
        Stage viewProductStage = new Stage();
        VBox layout = new VBox(20);
        layout.setPadding(new Insets(30));
        layout.setAlignment(Pos.CENTER);

        Label title = new Label("All Products");
        title.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #d63384;");

        ListView<String> productList = new ListView<>();
        for (Product product : Database.getProducts()) { // Get products from the database
            productList.getItems().add(product.toString());
        }

        Label backLabel = createBackLabel(viewProductStage, parentStage);

        layout.getChildren().addAll(title, productList, backLabel);

        Scene scene = new Scene(layout, 600, 400);
        viewProductStage.setScene(scene);
        viewProductStage.setTitle("View Products");
        viewProductStage.setFullScreen(true);
        viewProductStage.show();
        parentStage.hide();
    }

    private void openStockWindow(Stage parentStage) {
        Stage stockStage = new Stage();
        VBox layout = new VBox(20);
        layout.setPadding(new Insets(30));
        layout.setAlignment(Pos.CENTER);

        Label title = new Label("Product Stock Levels");
        title.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #d63384;");

        ListView<String> stockList = new ListView<>();
        for (Product product : Database.getProducts()) { // Get products from the database
            stockList.getItems().add(product.getName() + ": " + product.getStockQuantity() + " units");
        }

        Label backLabel = createBackLabel(stockStage, parentStage);

        layout.getChildren().addAll(title, stockList, backLabel);

        Scene scene = new Scene(layout, 600, 400);
        stockStage.setScene(scene);
        stockStage.setTitle("View Stock");
        stockStage.setFullScreen(true);
        stockStage.show();
        parentStage.hide();
    }

    private void openOrdersWindow(Stage parentStage) {
        Stage ordersStage = new Stage();
        VBox layout = new VBox(20);
        layout.setPadding(new Insets(30));
        layout.setAlignment(Pos.CENTER);

        Label title = new Label("View Orders");
        title.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #d63384;");

        ListView<String> ordersList = new ListView<>();
        for (Order order : Database.getOrders()) { // Get orders from the database
            ordersList.getItems().add(order.toString());
        }

        Label backLabel = createBackLabel(ordersStage, parentStage);

        layout.getChildren().addAll(title, ordersList, backLabel);

        Scene scene = new Scene(layout, 600, 400);
        ordersStage.setScene(scene);
        ordersStage.setTitle("View Orders");
        ordersStage.setFullScreen(true);
        ordersStage.show();
        parentStage.hide();
    }

    public static void main(String[] args) {
        launch(args);
    }
}

