package com.example.jouisvuitton;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class SignUpPage extends Application {
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Sign Up");

        // Ensure the database is initialized
        Database.initialize();

        StackPane signUp = new StackPane();
        signUp.setStyle("-fx-background-color: #f9dbe5; -fx-padding: 20;");

        GridPane signUpPane = new GridPane();
        signUpPane.setHgap(10);
        signUpPane.setVgap(15);
        signUpPane.setAlignment(Pos.CENTER);

        Label usernameL = new Label("Username:");
        usernameL.setFont(Font.font("Times New Roman", 18));
        TextField usernameTF = new TextField();

        Label passwordL = new Label("Password:");
        passwordL.setFont(Font.font("Times New Roman", 18));
        PasswordField passwordTF = new PasswordField();

        Label addressL = new Label("Address:");
        addressL.setFont(Font.font("Times New Roman", 18));
        TextField addressTF = new TextField();

        Label balanceL = new Label("Initial Balance:");
        balanceL.setFont(Font.font("Times New Roman", 18));
        TextField balanceTF = new TextField();

        Button signUpB = new Button("Sign Up");
        signUpB.setFont(Font.font("Times New Roman", 18));
        signUpB.setStyle("-fx-background-color: #c4a7b3; -fx-text-fill: white;");
        signUpB.setOnAction(e -> {
            String username = usernameTF.getText().trim();
            String password = passwordTF.getText().trim();
            String address = addressTF.getText().trim();
            String balanceStr = balanceTF.getText().trim();

            if (username.isEmpty() || password.isEmpty() || address.isEmpty() || balanceStr.isEmpty()) {
                showErrorMessage("All fields are required!");
                return;
            }

            try {
                double balance = Double.parseDouble(balanceStr);

                // Check if username already exists
                if (Database.findCustomerByCredentials(username, password) != null) {
                    showErrorMessage("Username already exists!");
                    return;
                }

                // Add new customer to the database
                Customer newCustomer = new Customer(username, password, balance, address, User.Gender.MALE, "clothes");
                Database.addCustomer(newCustomer);

                showSuccessMessage("Account created successfully!");
                openHomePage(primaryStage); // Navigate to the homepage
            } catch (NumberFormatException ex) {
                showErrorMessage("Invalid balance! Please enter a number.");
            } catch (Exception ex) {
                showErrorMessage("Failed to create account: " + ex.getMessage());
            }
        });

        signUpPane.add(usernameL, 0, 0);
        signUpPane.add(usernameTF, 1, 0);
        signUpPane.add(passwordL, 0, 1);
        signUpPane.add(passwordTF, 1, 1);
        signUpPane.add(addressL, 0, 2);
        signUpPane.add(addressTF, 1, 2);
        signUpPane.add(balanceL, 0, 3);
        signUpPane.add(balanceTF, 1, 3);
        signUpPane.add(signUpB, 1, 4);

        Image signUpImage = new Image("file:C:\\Users\\Mirei\\Desktop\\jouisVuitton\\src\\theme\\jvpink.jpg");
        ImageView sImageView = new ImageView(signUpImage);
        sImageView.setFitHeight(210);
        sImageView.setFitWidth(210);

        VBox signUpVBox = new VBox(20, sImageView, signUpPane);
        signUpVBox.setAlignment(Pos.TOP_CENTER);

        signUp.getChildren().add(signUpVBox);

        Scene signUpScene = new Scene(signUp, 800, 600);
        primaryStage.setScene(signUpScene);

        // Enable full-screen mode
        primaryStage.setFullScreen(true);

        primaryStage.show();
    }

    private void openHomePage(Stage primaryStage) {
        JouisVuittonECommerceApp ecommerceApp = new JouisVuittonECommerceApp();
        try {
            ecommerceApp.start(primaryStage); // Navigate to the homepage
        } catch (Exception e) {
            showErrorMessage("Failed to load homepage.");
        }
    }

    private void showErrorMessage(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Sign Up Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showSuccessMessage(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
